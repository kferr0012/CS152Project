Command Line Instructions

1) make

2) cat fibonacci.min | parser*


